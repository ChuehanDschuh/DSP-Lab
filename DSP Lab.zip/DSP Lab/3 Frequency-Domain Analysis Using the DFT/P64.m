clc;clear;close all;

fs = 8000;
mic = [19 18 1.6];
n = 12;
r = 0.8;
rm = [20 19 21];
src = [5 2 1];

h = rir(fs,mic,n,r,rm,src);

% stem(h);

speech = audioread("speech.wav");
% soundsc(speech);

y1 = conv(speech,h);
lh = length(h);
% soundsc(y1);

H = fft(h,16*lh);
figure;plot(abs(H));
H = fftshift(H);
figure;plot(abs(H));
Hi = 1./H;
hi = ifft(Hi,16*lh);
figure;stem(hi);
hi = ifftshift(hi);
figure;stem(hi);

y2 = conv(speech,hi);
% soundsc(y2);

% lh = length(h);
% lH = (0:lh/2)/lh*fs;
% if mod(lh,2)
%     H_1side = H(1:(lh-1)/2+1);
% else
%     H_1side = H(1:lh/2+1);
% end

% 
% figure;plot(abs(H));
% Hi = 1./H;
% figure;plot(abs(Hi));
% 
% 
% hi = ifft(Hi);
% figure;stem(hi)

% r = conv(hi,o);
% soundsc(r);

