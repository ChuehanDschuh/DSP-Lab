%Preparation1
clc;clear;

n = -10:1:20;
delta = +(n==0);
u = +(n>=0);

x1 = sin(0.12*pi*n);
x2 = (+(n>=0)) - (+(n>=6));
x3 = 0.9.^n.*u;
x4 = 0.5*(n==1)+(n==2)+0.5*(n==3);
x5 = 0.9.^n.*cos(0.2*pi*n);
x6 = sin(0.2*pi*n)./(0.2*pi*n);x6(delta==1) = 1;

