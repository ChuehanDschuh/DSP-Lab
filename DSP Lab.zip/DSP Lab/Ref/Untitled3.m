N = 100;
muZ=0;
theta=1;
si=ones(100,1);
SNR1=10;
sigmaZ1=sqrt(10^(-SNR1/10));
SNR2=0;
sigmaZ2=sqrt(10^(-SNR2/10));
SNR3=-10;
sigmaZ3=sqrt(10^(-SNR3/10));

[x1,x2,x3] = genSignals(N, si, theta, muZ, sigmaZ1, sigmaZ2, sigmaZ3);
plot(x1)

[s1, s2, s3] = detector(x1, x2, x3, sigmaZ1, sigmaZ2, sigmaZ3);