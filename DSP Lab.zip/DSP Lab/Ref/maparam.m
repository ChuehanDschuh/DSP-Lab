function [] = maparam()

load('ma3.mat')

for n=1:1024
 for m=1:3
y = circshift(x,m);
 end
end

end

