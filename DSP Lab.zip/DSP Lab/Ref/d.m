function [s1, s2, s3] = d(x1, x2, x3, sigmaZ1, sigmaZ2, sigmaZ3)
%H ; theta = 0    0
%K : theta > 0    1
alpha = 0.12;
N = 100;
muZ=0;
theta=1;
si=ones(100,1);
SNR1=10;
sigmaZ1=sqrt(10^(-SNR1/10));
SNR2=0;
sigmaZ2=sqrt(10^(-SNR2/10));
SNR3=-10;
sigmaZ3=sqrt(10^(-SNR3/10));

[x1,x2,x3] = genSignals(N, si, theta, muZ, sigmaZ1, sigmaZ2, sigmaZ3);
plot(x1)

lamda1 = N^(1/2) * 2^(1/2) * sigmaZ1 * erfinv(1-2*alpha);
T1 = sum(x1);
if T1 > lamda1
    s1 = 1;
else
    s1 = 0;
end

lamda2 = N^(1/2) * 2^(1/2) * sigmaZ2 * erfinv(1-2*alpha);
T2 = sum(x2);
if T2 > lamda2
    s2 = 1;
else
    s2 = 0;
end

lamda3 = N^(1/2) * 2^(1/2) * sigmaZ3 * erfinv(1-2*alpha);
T3 = sum(x3);
if T3 > lamda3
    s3 = 1;
else
    s3 = 0;
end
disp(s1)
disp(s2)
disp(s3)
disp(lamda3)
end

