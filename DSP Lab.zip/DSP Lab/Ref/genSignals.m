function [x1, x2, x3] = genSignals(N, si, theta, muZ, sigmaZ1, sigmaZ2, sigmaZ3)

N1 = normrnd(muZ,sigmaZ1,N,1);
N2 = normrnd(muZ,sigmaZ2,N,1);
N3 = normrnd(muZ,sigmaZ3,N,1);


x1=theta*si+N1;
x2=theta*si+N2;
x3=theta*si+N3;


end

