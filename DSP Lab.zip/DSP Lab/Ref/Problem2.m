wp = 0.12*pi;
ws = 0.16*pi;
w0 = 0.25*pi;
%N=51;
deltaw = 0.06*pi;
deltawbp = 0.3*pi;
A=40;
[N,beta,kaiw] = kwin(deltaw,A);

wc= (wp+ws)/2;
alpha=(N-1)/2;
wch= pi-wc;

for n=1:N
hl(n)= sinc(wc*(n-alpha)/pi); %Impulse Response of Low Pass 
hh(n) = (-1).^n*sinc(wch*(n-alpha)/pi);  %Impulse response of HighPass
hb(n) = (2*cos(n*w0)) *sinc(wc*(n-alpha)/pi); %Impulse Response of BandPass
end

hkl = hl.*kaiw;  %Windowing with a Kaiser Window
hkh = hh.*kaiw;  %h+low/high/band
hkb = hb.*kaiw;

%Comment/Uncomment to:
% Plot 2 Impulse Responses from h1,hh,hb,hkl,hkh, hkb
% figure();
% stem(h1kaise)
% figure();
% stem(hbkai)
freqz(hkl,1,512)
title('low pass filter with Kaiser method')
ylabel('magnitude/dB')


%Plot Frequency Response
w=(0:255)/256; % Create The Frequency Space

[Hkl,w1] = freqz(hkh,1,512); %Frequency Response
[Hkh,w2] = freqz(hkb,1,512); %Frequency Response
%fvtool(Hk,1)  %Optional Method for Frequency Analisis

%Plot Frequency Responses
figure();
plot(w1/pi,20*log(abs(Hkl)))
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')
figure();
plot(w2/pi,20*log(abs(Hkh))) 
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')


