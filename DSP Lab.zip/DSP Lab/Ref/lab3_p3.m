fs=8000;
y1=dtmfdial('7',fs);
plot(y1)
N=256;
f=fs*(0:1/N:1-1/N);
Y1=fft(y1,N);
plot(abs(Y1))
title('DTFT of y1')
xlabel('f')
ylabel('Y1')
a=abs(Y1);
p=a.*a/10000; 
plot(p)


load('mynumber.mat')
s1=xx(1,1:320);
s2=xx(1,321:640);
s3=xx(1,641:960);
s4=xx(1,961:1280);
s5=xx(1,1281:1600);
s6=xx(1,1601:1920);
s7=xx(1,1921:2240);
s8=xx(1,2241:2560);
s9=xx(1,2561:2880);
s10=xx(1,2881:3200);
s11=xx(1,3201:3520);

S1=fft(s1,N);
S2=fft(s2,N);
S3=fft(s3,N);
S4=fft(s4,N);
S5=fft(s5,N);
S6=fft(s6,N);
S7=fft(s7,N);
S8=fft(s8,N);
S9=fft(s9,N);
S10=fft(s10,N);
S11=fft(s11,N);

plot(abs(S1));
n1=dtmfcoef(S1,N);
n2=dtmfcoef(S2,N);
n3=dtmfcoef(S3,N);
n4=dtmfcoef(S4,N);
n5=dtmfcoef(S5,N);
n6=dtmfcoef(S6,N);
n7=dtmfcoef(S7,N);
n8=dtmfcoef(S8,N);
n9=dtmfcoef(S9,N);
n10=dtmfcoef(S10,N);
n11=dtmfcoef(S11,N);

A=[n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11];
B=A(:);
number=B.';
disp(number)



 
 

