function [s1, s2, s3] = detector(x1, x2, x3, sigmaZ1, sigmaZ2, sigmaZ3,muk1,muk2,muk3)


muh=0;
N=100;
SNR1=10;
sigmaZ1=sqrt(10^(-SNR1/10));
SNR2=0;
sigmaZ2=sqrt(10^(-SNR2/10));
SNR3=-10;
sigmaZ3=sqrt(10^(-SNR3/10));
alpha=0.12;
p=1-alpha;
lamba1 = norminv(p,muh,sigmaZ1);
lamba2 = norminv(p,muh,sigmaZ2);
lamba3 = norminv(p,muh,sigmaZ3);
yk1 = normpdf(x1,muk1,sigmaZ1);
yh1= normpdf(x1,muh,sigmaZ1);
L1=yk1./yh1;
for m=1:N
    if L1(m)>lamba1
        s1(m)=1;
    else
        s1(m)=0;
    end  
end


yk2 = normpdf(x2,muk2,sigmaZ2);
yh2= normpdf(x2,muh,sigmaZ2);
L2=yk2./yh2;
for m=1:N
    if L2(m)>lamba2
        s2(m)=1;
    else
        s2(m)=0;
    end  
end

yk3 = normpdf(x3,muk3,sigmaZ3);
yh3= normpdf(x3,muh,sigmaZ3);
L3=yk3./yh3;
for m=1:N
    if L3(m)>lamba3
        s3(m)=1;
    else
        s3(m)=0;
    end  
end
R=[s1, s2, s3];
disp(R)
disp(lamba1)
disp(lamba2)
disp(lamba3)
end

