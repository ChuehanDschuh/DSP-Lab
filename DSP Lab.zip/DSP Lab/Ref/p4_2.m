
N1 = 10;   % Filters Length
N2 = 25;
N3 = 50;

f = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.8 0.9 1];  %Frequency Specification
a = [ 0 0 1 1 0 0 0.5 0.5 0 0];   %Define if Stop/Pass-Bands Sections
b1 = firpm(N1,f,a);    %Filtering
b2 = firpm(N2,f,a);
b3 = firpm(N3,f,a);

%stem(b3);
[h1,w1] = freqz(b1,1,512);  %Frequency Response
[h2,w2] = freqz(b2,1,512);
[h3,w3] = freqz(b3,1,512);

figure();
plot(w1/pi,20*log(abs(h1)))
title('Frequency Response at N= 10') %DB-Plot
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')
figure();
plot(w2/pi,20*log(abs(h2)))
title('Frequency Response at N= 25') 
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')
figure();
plot(w3/pi,20*log(abs(h3)))
title('Frequency Response at N= 50') 
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (dB)')
