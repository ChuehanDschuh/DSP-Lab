Ts = 10;
Fs = 1/Ts;
%% 原始信号
t = 0:Ts:pi/2;
yt = sin(2*pi*5*t) + sin(2*pi*10*t) + sin(2*pi*15*t);

win = hann(length(t));
yt1 = yt.*win';


for i = 1:n
     A = 你的操作;
     Data{i} = A;
end