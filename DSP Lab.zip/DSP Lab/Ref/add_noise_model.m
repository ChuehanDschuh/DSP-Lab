function [Y,NOISE] = add_noise_model(X,SNR1,SNR2)
load('noise_5insx.mat')
SNR1=10;
SNR2=-10;
X=ones(100,1);
NOISE=randn(100,1);
NOISE=NOISE-mean(NOISE);
signal_power = 1/length(X)*sum(X.*X);
noise_variance1 = signal_power / ( 10^(SNR1/10) );
NOISE1=sqrt(noise_variance1)/std(NOISE)*NOISE;
noise_variance2 = signal_power / ( 10^(SNR2/10) );
NOISE2=sqrt(noise_variance2)/std(NOISE)*NOISE;
Y=X+NOISE1;
Y2=X+NOISE2;
plot(Y)
hold on 
plot (Y2)

end
