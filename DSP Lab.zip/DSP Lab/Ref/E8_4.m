
%sound of voice
load('s5.mat')
soundsc(s5)
plot(s5)
SH=s5(15600:16300,1);
AA=s5(16800:17500,1);
soundsc(SH)
soundsc(AA)


SHw=fft(SH);
NS=length(SH);
rS=2*abs(SHw(1:NS/2+1))/NS;
XS=(0:NS/2)*(1/NS);
figure;
%plot(XS,rS);
plot(XS,10*log10(rS))
ylabel('magnitude/dB')
title('original SH signal sepctrum')


AAw=fft(AA);
NA= length(AA); 
rA=2*abs(AAw(1:NA/2+1))/NA;
XA=(0:NA/2)*(1/NA);
figure;
semilogy(XA,rA) 
ylabel('magnitude/dB')
title('original AA signal sepctrum')

%plot(15600:16300,SH)
%plot(16800:17500,AA)


%AR(10) model
Z=randn(701,1);%sigma^2=1
aS= aryule(SH,10);
aA= aryule(AA,10);
YS=filter(1,aS,Z);
YH=filter(1,aA,Z);
freqz(1,aA)
ylabel('magnitude/dB')
xlabel('normalized frequency')
title('estimated sepctrum of AA signal under AR(10) model ')
freqz(1,aS)
ylabel('magnitude/dB')
xlabel('normalized frequency')
title('estimated sepctrum of SH signal under AR(10) model ')


%window periodogram
NS = length(SH);
nsc = floor(NS/4.5);
nov = floor(nsc/2);
%nff = maSH(256,2^neSHtpow2(nsc));
ts = pwelch(SH,hamming(nsc),nov);
plot(10*log10(ts))
ylabel('magnitude/dB')
title('estimated sepctrum of SH signal with windowed averaged periodogram')

NA = length(AA);
nscA= floor(NA/4.5);
novA = floor(nscA/2);
%nffA = maSH(256,2^neSHtpow2(nscA));
tA = pwelch(AA,hamming(nscA),novA);
plot(10*log10(tA))
ylabel('magnitude/dB')
title('estimated sepctrum of AA signal with windowed averaged periodogram')


%AIC calculate order

N=701;
k=1:10;
a1= aryule(SH,1); a2= aryule(SH,2);a3= aryule(SH,3); a4= aryule(SH,4);
a5= aryule(SH,5);a6= aryule(SH,6);a7= aryule(SH,7);a8= aryule(SH,8);
a9= aryule(SH,9);a10= aryule(SH,10);a11= aryule(SH,11);a12= aryule(SH,12);
a13= aryule(SH,13);a14= aryule(SH,14);a15= aryule(SH,15);a16= aryule(SH,16);
a17= aryule(SH,17);a18= aryule(SH,18);a19= aryule(SH,19);a20= aryule(SH,20);
a21= aryule(SH,21);a22= aryule(SH,22);a23= aryule(SH,23);a24= aryule(SH,24);
a25= aryule(SH,25);a26= aryule(SH,26);a27= aryule(SH,27);a28= aryule(SH,28);
a29= aryule(SH,29);a30= aryule(SH,30);a31= aryule(SH,31);a32= aryule(SH,32);
a33= aryule(SH,33);a34= aryule(SH,34);a35= aryule(SH,35);
a=[a1 a2 a3 a4 a5 a6 a7 a8 a9 a10 a11 a12 a13 a14 a15 a16 a17 a18 a19 a20 a21 a22 a23 a24 a25 a26 a27 a28 a29 a30 a31 a32 a33 a34 a35];


for m=1:35
 for k=1:m
  for n=m+1:N
   for numb=2:k
   f=sum(numb);
  s1(k,n,f)=sum(a(1,f:f+k)*SH(n-k));
  s2(n)=sum((SH(n)+s1(k,n,f))^2);
  sigmazm2(m)=1/(N-m)*s2(n);
  AIC(m)=log(sigmazm2(m))+m*2/N;
%MDL(m)=log(sigmazm2(m))+m*log(N)/N;
   end
  end
 end
end
m=1:35;
plot(m,AIC)
xlabel('m')
ylabel('the value of AIC')

%Z=randn(701,1);%sigma^2=1
aS5= aryule(SH,5);
aA5= aryule(AA,5);
YS5=filter(1,aS5,Z);
YH5=filter(1,aA5,Z);
freqz(1,aA5)
ylabel('magnitude/dB')
xlabel('normalized frequency')
title('estimated sepctrum of AA signal under AR(5) model ')
freqz(1,aS5)
ylabel('magnitude/dB')
xlabel('normalized frequency')
title('estimated sepctrum of SH signal under AR(5) model ')


