N=17;
wc=0.5*pi;
h1=firlp(N,wc);
alpha=(N-1)/2;
wr1 = rectwin(N);
hr1= h1.*wr1';
stem(hr1)
title('impulse response (N=17,rectwin)')
M=8*N;
Hr1=fft(hr1,M);
plot(abs(Hr1))
P2 = abs(Hr1/M);
P1 = P2(1:(M/2+1));
P1(2:end-1) = 2*P1(2:end-1);
f=(0:(M/2))/M;



wb = bartlett(N);
hb1= h1.*wb';
freqz(hb1,1,512)
stem(hb1)
title('impulse response (N=17,bartlett)')
M=8*N;
Hb1=fft(hb1,M);
plot(abs(Hb1))
P2b1 = abs(Hb1/M);
P1b1 = P2b1(1:(M/2+1));
P1b1(2:end-1) = 2*P1b1(2:end-1);
f =(0:(M/2))/M;

wh = bartlett(N);
hh1= h1.*wh';

stem(hh1)
title('impulse response (N=17,hamming)')
M=8*N;
Hh1=fft(hh1,M);
plot(abs(Hh1))
P2h1 = abs(Hh1/M);
P1h1 = P2h1(1:(M/2+1));
P1h1(2:end-1) = 2*P1h1(2:end-1);
f =(0:(M/2))/M;

N1=51;
wc=0.5*pi;
h2=firlp(N1,wc);
alpha1=(N1-1)/2;
wr2 = rectwin(N1);
hr2= h2.*wr2';
stem(hr2)
title('impulse response (N1=51,rectwin)')
M1=8*N1;
Hr2=fft(hr2,M1);
plot(abs(Hr2))
P2r2 = abs(Hr2/M1);
P1r2 = P2r2(1:(M1/2+1));
P1r2(2:end-1) = 2*P1r2(2:end-1);
f1 =(0:(M1/2))/M1;

wb2 = bartlett(N1);
hb2= h2.*wb2';
stem(hb2)
title('impulse response (N=51,bartlett)')
M1=8*N1;
Hb2=fft(hb2,M1);
plot(abs(Hb2))
P2b2 = abs(Hb2/M1);
P1b2 = P2b2(1:(M1/2+1));
P1b2(2:end-1) = 2*P1b2(2:end-1);
f1 =(0:(M1/2))/M1;

wh2 = bartlett(N1);
hh2= h2.*wh2';
stem(hh2)
title('impulse response (N=51,hamming)')
M1=8*N1;
Hh2=fft(hh2,M1);
plot(abs(Hh2))
P2h2 = abs(Hh2/M1);
P1h2 = P2h2(1:(M1/2+1));
P1h2(2:end-1) = 2*P1h2(2:end-1);
f1 =(0:(M1/2))/M1;


freqz(hr1,1,512)
title('frequency response for N=17(rectangular)')
ylabel('magnitude/dB')

freqz(hr2,1,512)
title('frequency response for N=51(rectangular)')
ylabel('magnitude/dB')

freqz(hb1,1,512)
title('frequency response for N=17(bartlett)')
ylabel('magnitude/dB')

freqz(hb2,1,512)
title('frequency response for N=51(bartlett)')
ylabel('magnitude/dB')

freqz(hh1,1,512)
title('frequency response for N=17(hamming)')
ylabel('magnitude/dB')

freqz(hh2,1,512)
title('frequency response for N=51(hamming)')
ylabel('magnitude/dB')



subplot(3,2,1)
powerbw(P1,f)
subplot(3,2,2)
powerbw(P1r2,f1)
subplot(3,2,3)
powerbw(P1b1,f)
subplot(3,2,4)
powerbw(P1b2,f1)
subplot(3,2,5)
powerbw(P1h1,f)
subplot(3,2,6)
powerbw(P1h2,f1)






