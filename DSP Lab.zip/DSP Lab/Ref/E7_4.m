[data]=importdata('group09.txt');
DH=data(1,:);

D1= detrend(DH,0);
D2=detrend(D2,1);


