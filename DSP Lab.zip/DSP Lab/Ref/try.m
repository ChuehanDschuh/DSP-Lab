F=1;
T=0.05;
for n=0:100
s = sin(2*pi*F*n*T);
end
plot(n,s)