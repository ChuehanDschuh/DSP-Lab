fs=8192;
x=linspace(0,2*pi,fs);
f1=392;
y=sin(f1*x);
plot(y);
soundsc(y,fs);

fk=[f1,2*f1,3*f1,4*f1,5*f1,6*f1,7*f1,8*f1];
y1=sin(fk(1)*x);
y2=(0.25)*sin(fk(2)*x);
y3=(0.25)^2*sin(fk(3)*x);
y4=(0.25)^3*sin(fk(4)*x);
y5=(0.25)^4*sin(fk(5)*x);
y6=(0.25)^5*sin(fk(6)*x);
y7=(0.25)^6*sin(fk(7)*x);
y8=(0.25)^7*sin(fk(8)*x);
ys=[y1+y2+y3+y4+y5+y6+y7+y8];
sound(ys,fs)

yx=envelope.*ys;
plot(yx);
xlabel('t')
ylabel('yx')
Yx=fft(yx,fs);
plot(Yx)
xlabel('f')
ylabel('Yx')
sound(yx,fs)
 
load pianoG3.mat;
G=fft(g,fs);
plot(G);
xlabel('f')
ylabel('G')
sound(g,fs)


