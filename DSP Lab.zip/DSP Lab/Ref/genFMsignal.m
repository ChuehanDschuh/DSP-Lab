function FM = genFMsignal(alpha, beta, gamma, fc, fs, tStart, tStop)


% fs = 1000; %Sampling frequency
% tStart = 0;
% tStop = 3.04;
t = (tStart:1/fs:tStop);
% fc = 100;
% alpha= 50;
% beta = 1.5;
% gamma = pi/3;

%wi = 2*pi*fc + 2*pi*alpha*cos(2*pi*beta*t+ gamma);

Phi = alpha*cos(2*pi*beta*t+ gamma);


FM = cos(2*pi*fc*t + Phi);
%plot(x)










