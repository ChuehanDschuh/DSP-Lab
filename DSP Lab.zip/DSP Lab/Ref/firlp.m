function [hd] = firlp(N,wc)
alpha=(N-1)/2;
Ts = 1;
Fs = 1/Ts;
for n = 1:N
h=sinc(wc*n/pi);
hd(n)=sinc(wc*(n-alpha)/pi);
end
stem(hd)
end

