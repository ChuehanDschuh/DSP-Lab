function [X] = dft(N,x);
N=32;
n=0:N-1;
x=0.8*sin(0.2*pi*n);
stem(n,x);
X=x*dftmtx(N);
wk=2*pi*(0:1/N:1-1/N);
stem(wk,abs(X))
end

