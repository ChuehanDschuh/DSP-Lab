N=51;
alpha=(N-1)/2;
Hmag=[ones(1,4),zeros(1,22)];
wk=2*pi/N*(0:alpha);
Hphi=exp(-1i*wk*alpha);
H=Hmag.*Hphi;
H=[H,conj(H(end:-1:2))];
h=ifft(H);
stem(h)
plot(abs(H))
freqz(h,1,512)
title('low pass filter with frequency sampling method')
ylabel('magnitude/dB')