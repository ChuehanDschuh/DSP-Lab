%function [] = calc_STFT(L, )

%creates FM-Signal
x = genFMsignal(50, 1.5,pi/3, 100, 1000, 0,3.04);

%Variables
L=100;  %Lenght of the window to have an appropiated FFT value of 128
% 128  = 4*pi / T --> T = 4*pi/128*fs
N= round(length(x)/L); %numero de cortes
K=128; %frequeny slots?

rw = hamming(L);

S = zeros(N,128);

for i= (0:1:N-1)
    for j=(1:1:100)
        wf(j) = rw(j)*x(i*100+j);
    end
    WF = fft(wf,128);
    S(i+1,:) = WF;
end


x = [0 1000];
y = [0 128];
figure();
imagesc(x,y,abs(S))


% figure();    
% stem(abs(S(1,:)))
% figure();
% stem(abs(S(2,:)))




