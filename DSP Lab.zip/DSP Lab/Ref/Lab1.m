
M=magic(5);
sum(M)
sum(M')
M(1,1:end)
M(1:end,3)
M(2,1:3)
A=M<4;
B=M>10;

clc
x=rand(1000,1);
C=max(x);
B=min(x);
A=mean(x);
D=std(x);
y=4*x-2;
max(y) 
min(y)
mean(y)
std(y)

f=randn(1000,1);
min(f)
max(f)
mean(f)
std(f)
hist(f)



    
  
  




    
    
    
    












    