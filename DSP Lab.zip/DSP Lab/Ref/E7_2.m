N=32;
n=0:N-1;
x=0.8*sin(0.2*pi*n);
Xw=x*dftmtx(N);
stem(abs(Xw))
Ixx=((abs(Xw)).^2)/N;
Cxx = spec2(x,N);
k=0:N-1;
wk=2*pi*k/N;
stem(wk,Cxx)



load('ar7.mat')
N1=1000;
Xf=fft(X);
Ixx=((abs(Xf)).^2)/N1;
plot(Ixx)
%title('The original periodogram of data')
Cxx2 = spec2(X,N1);
plot(Cxx2)
title('The smoothing periodogram (m=35)')


