load('ma3.mat')


%m=-3:3;
y1 = circshift(x,-3);
r1=xcorr(x,y1);
cxx1=(1/1021)*sum(r1);
y2 = circshift(x,-2);
r2 = xcorr(x,y2);
cxx2=(1/1022)*sum(r2);
y3 = circshift(x,-1);
r3 = xcorr(x,y3);
cxx3=(1/1023)*sum(r3);
y4 = circshift(x,0);
r4 = xcorr(x,y4);
cxx4=(1/1024)*sum(r4);
y5 = circshift(x,1);
r5 = xcorr(x,y5);
cxx5=(1/1023)*sum(r5);
y6 = circshift(x,2);
r6= xcorr(x,y6);
cxx6=(1/1022)*sum(r6);
y7 = circshift(x,3);
r7 = xcorr(x,y7);
cxx7=(1/1021)*sum(r7);

cxx=[ cxx1 cxx2 cxx3 cxx4 cxx5 cxx6 cxx7];
Cxx(z)=cxx1*z^3+cxx2*z^2+cxx3*z^1+cxx4*z^0+cxx5*z^(-1)+cxx6*z^(-2)+cxx7*z^(-1);
P(z)=z^3*Cxx(z);
root(P(z),z)



