function [Cxxs] = spec3(N,X,m)

Xw=fft(X);
Ixx=((abs(Xw)).^2)/N;
for n=1:N
if n>m&&n<N-m+1
    for n=m+1:N-m+1
    C=Ixx(m+1:N-m+1,1);
    Cxxs(n)=sum(C)/(2*m+1);
    end
elseif n<m+1
    for n=1:m
       C=Ixx(1:2*n-1,1);
       Cxxs(n)=sum(C)/(2*n-1);
    end
else
    for n=N-m+1:N
        C=Ixx(2*n-N:N,1);
        Cxxs(n)=sum(C)/(2*N-2*n+1);
    end
end
end
plot(Cxxs)
end

