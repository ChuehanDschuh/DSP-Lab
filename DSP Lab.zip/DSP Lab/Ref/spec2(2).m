%function [x,y] = spec()


load ar7.mat;


L= 10;
M= round(size(X,1) / L);

L= 10;
M= size(X,1) / L;
s= [];

for i = (0:L-1)
    for j = (1:M)
        s(i+1,j) = X(i*M+j,1);
    end
end

rw = hamming(M);
ss = [];
SS = ones(L,M);
Ps = ones(L,M);

for i = (0:L-1)
    for j = (1:M)
        ss(i+1,j) = rw(j) * s(i+1,j);
        SS(i+1,:) = fft(ss(i+1,:),M);
        Ps(i+1,:) = (abs(SS(i+1,:))).^2 ./ sum(abs(rw).^2) ;
        
    end
end

% ss1 = rw' .* s;
% 
% SS1 = fft(ss1(1,:), M);
% 
% SSAb1 = (abs(SS1).^2) ./ sum(rw.^2) ;

suma = sum(Ps);

Cxx = suma ./ L;
CxxL= 10*log10(Cxx);
figure();
plot(Cxx(M/2:M))

confn = CxxL  -  (10*log10( abs(norminv(0.025)/sqrt(L)))) ;
confp = CxxL  +  (10*log10( abs(norminv(0.025)/sqrt(L)))) ;
figure();
plot(CxxL(M/2:M));
hold on
plot(confn(M/2:M));
hold on
plot(confp(M/2:M));
hold off




