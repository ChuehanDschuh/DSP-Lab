function varargout = pushbuttonNUM_Callback(h, eventdata, handles, varargin)

global NUM

%wavplay(NUM,8192);

L=length(NUM);

n=L/1100;

number='';

for i=1:n

j=(i-1)*1100+1;

d=NUM(j:j+999); % 截取出每个数字

f=fft(d,2048); % 以 N=2048 作 FFT 变换

a=abs(f);

p=a.*a/10000; % 计算功率谱

num(1)=find(p(1:250)==max(p(1:250))); % 找行频

num(2)=300+find(p(300:380)==max(p(300:380))); % 找列频

if (num(1) < 180) row=1; % 确定行数

elseif (num(1) < 200) row=2;

elseif (num(1) < 220) row=3;

else row=4;

end

if (num(2) < 320) column=1; % 确定列数

elseif (num(2) < 340) column=2;

else column=3;

end

z=[row,column]; % 确定数字

if z==[4,2] tel=0;

elseif z==[1,1] tel=1;

elseif z==[1,2] tel=2;

elseif z==[1,3] tel=3;

elseif z==[2,1] tel=4;

elseif z==[2,2] tel=5;

elseif z==[2,3] tel=6;

elseif z==[3,1] tel=7;

elseif z==[3,2] tel=8;

elseif z==[3,3] tel=9;

end

t(i)=tel;

c=strcat(number,int2str(tel));

number=c;

i=i+1;
disp(number)
end

