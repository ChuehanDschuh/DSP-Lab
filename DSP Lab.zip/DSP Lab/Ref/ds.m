T=0.05;
F=1;
n=0:100;
s=sin(2*pi*F*n*T);
plot(n,s);
plot(n*T,s);
stem(n,s);

S=fft(s,128);
P=S.*conj(S);
w=(0:127)/128;
plot(2*w,P)
plot(w/T,P)

s2=s+sin(2*2*pi*4*n*T);
plot(n,s)
hold on
plot(n,s2)
S2=fft(s2,128);
P2=S2.*conj(S2);
plot(2*w,P)
hold on
plot(2*w,P2)

b=[1 1 1 1 ]/4;
a=1;
[H,w1]=freqz(b,a);
plot(w1/(2*pi*T),abs(H))
sf=filter(b,a,s2);
plot(n,sf)
SF=fft(sf,128);
PF=SF.*conj(SF);
plot(2*w,PF)


