function [Cxx,CxxL] = spec(x,L)

%load ar7.mat;
% n= 0:1:63;
% variance = 0.5;
% x = sin(0.2*pi*n)+2*sin(0.4*pi*n) +sin(0.45*pi*n)+ sqrt(variance)*randn(size(n));;
X = x';

M= round(size(X,1) / L);
Mhalf = round(M/2);
s= [];

for i = (0:L-1)
    for j = (1:M)
        s(i+1,j) = X(i*M+j,1);
    end
end

rw = rectwin(M);
ss = []
SS = ones(L,M);
Ps = ones(L,M);

for i = (0:L-1)
    for j = (1:M)
        ss(i+1,j) = rw(j) * s(i+1,j);
        SS(i+1,:) = fft(ss(i+1,:),M);
        Ps(i+1,:) = (abs(SS(i+1,:))).^2 ./ sum(abs(rw).^2) ;
        
    end
end

% ss1 = rw' .* s;
% 
% SS1 = fft(ss1(1,:), M);
% 
% SSAb1 = (abs(SS1).^2) ./ sum(rw.^2) ;

suma = sum(Ps);

Cxx = suma ./ L;
CxxL= 10*log10(Cxx);
figure();
plot(CxxL(Mhalf:M))

confn = CxxL  -  (10*log10( abs(norminv(0.025)/sqrt(L)))) ;
confp = CxxL  +  (10*log10( abs(norminv(0.025)/sqrt(L)))) ;
figure();
plot(CxxL(Mhalf:M));
hold on
plot(confn(Mhalf:M));
hold on
plot(confp(Mhalf:M));
hold off



