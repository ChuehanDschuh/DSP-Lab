function [R] = MA(N,m,n)
load glob_warm.mat
N=length(Ta);
m=25;
for n=1:N
if n>m&&n<N-m+1
    for n=m+1:N-m+1
    x=Ta(m+1:N-m+1,1);
    R(n)=sum(x)/(2*m+1);
    end
elseif n<m+1
    for n=1:m
       x=Ta(1:2*n-1,1);
       R(n)=sum(x)/(2*n-1);
    end
else
    for n=N-m+1:N
        x=Ta(2*n-N:N,1);
        R(n)=sum(x)/(2*N-2*n+1);
    end
end
plot(R)
hold on
y=smooth(R(:));
plot(y,'g:*')
xlabel('n')
ylabel('R')
legend('R','smooth R')
end
end


