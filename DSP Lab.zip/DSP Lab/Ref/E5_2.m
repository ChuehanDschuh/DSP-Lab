fs=200;
fpb=32;
fsb=38;
Wp=2*fpb/fs;
Ws=2*fsb/fs;
Rp=1;
Rs=25;
[n1,Wn1] = buttord(Wp,Ws,Rp,Rs);
[n2,Wn2] = cheb1ord(Wp,Ws,Rp,Rs);
[n3,Wn3]=ellipord(Wp,Ws,Rp,Rs);

[b,a] = butter(n1,Wn1);
[z1,p1,k1] = butter(n1,Wn1);         
freqz(b,a) 
title('frequency response')
ylabel('Amplitude/dB')
xlabel('normalized frequency')
zplane(z1,p1)
title('pole-zero locaation diagram')
xlabel('real part')
ylabel('imaginary part')
impz(b,a)
title('impulse response')
ylabel('magnitude')


[b2,a2] = cheby1(n2,Rp,Wp);
[z2,p2,k2] = cheby1(n2,Rp,Wp);         
freqz(b2,a2) 
title('frequency response')
ylabel('Amplitude/dB')
xlabel('normalized frequency')
zplane(z2,p2)
title('pole-zero locaation diagram')
xlabel('real part')
ylabel('imaginary part')
impz(b2,a2)
title('impulse response')
ylabel('magnitude')

[b3,a3] = ellip(n3,Rp,Rs,Wp);
[z3,p3,k3] = ellip(n3,Rp,Rs,Wp);      
freqz(b3,a3) 
title('frequency response')
ylabel('Amplitude/dB')
xlabel('normalized frequency')
zplane(z3,p3)
title('pole-zero locaation diagram')
xlabel('real part')
ylabel('imaginary part')
impz(b3,a3)
title('impulse response')
ylabel('magnitude')


f4=[32 38];
a4=[1 0];
dev = [(10^(Rp/20)-1)/(10^(Rp/20)+1) 10^(-Rs/20)]; 
[n4,fo4,ao4,w4] = firpmord(f4,a4,dev,fs);
b = firpm(n4,fo4,ao4,w4);
freqz(b,1,1024,fs)
title('frequency response of optimum FIR lowpass filter ')
ylabel('magnitude/dB')
xlabel('frequency')



