
%Create Sinusoidal function
n= 0:1:63;
variance = 0.5;
x = sin(0.2*pi*n)+2*sin(0.4*pi*n) +sin(0.45*pi*n)+ sqrt(variance)*randn(size(n));
%plot(n,x)  %For Plotting the Function


win = rectwin(64);
pxx= periodogram(x,win,192);
figure();
plot(pxx);
figure();
plot(10*log10(abs(pxx)))


[CxxS,CxxLS] = spec(x,2);

