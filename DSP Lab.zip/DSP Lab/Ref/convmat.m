function [B] = convmat(x,n,h)
m=[1,2,3];
h=m.';
n=4;
f=[1,2,3,4,5,6];
x=f.';
A=convmtx(h,n);
B=A.*x;
end



