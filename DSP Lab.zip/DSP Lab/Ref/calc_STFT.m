function [S] = calc_STFT(x,Ts,L)
x=read_radar_data('G09_NormalWalking1.dat');
L=256;
Ts=10;
N= round(length(x)/L);
K=2048;
rw = hamming(L);


S = zeros(N,K);

for i= (0:1:N-1)
    for j=(1:1:100)
        wf(j) = rw(j)*x(i*100+j);
    end
    WF = fft(wf,K);
    S(i+1,:) = WF;
end

figure();
imagesc(abs(S))

end

