load b3pulses.mat
Fs=80;
dw1=(8-5)*2*pi/Fs;
dw2=(15.5-10.5)*2*pi/Fs;
dw3=(20-18)*2*pi/Fs;
r1=[(8+dw1^2)-((8+dw1^2)^2-64)^0.5]/8;
r2=[(8+dw2^2)-((8+dw2^2)^2-64)^0.5]/8;
r3=[(8+dw3^2)-((8+dw3^2)^2-64)^0.5]/8;
w01=dw1/2+5*2*pi/Fs;
w02=dw2/2+10.5*2*pi/Fs;
w03=dw3/2+18*2*pi/Fs;
b=[1,0,-1];
a1=[1,-2*r1*cos(w01),r1^2];
a2=[1,-2*r2*cos(w02),r2^2];
a3=[1,-2*r3*cos(w03),r3^2];
[H1,w]=freqz(b,a1);
plot(w/pi,20*log10(abs(H1)))
title('H1')
hold on
[H2,w]=freqz(b,a2);
plot(w/pi,20*log10(abs(H2)))
title('H2')
hold on
[H3,w]=freqz(b,a3);
plot(w/pi,20*log10(abs(H3)))
title('H3')

plot(x)
xf1=filter(b,a1,x);
plot(xf1)
title('xf1')
xf2=filter(b,a2,x);
plot(xf2)
title('xf2')
xf3=filter(b,a3,x);
plot(xf3)
title('xf3')




