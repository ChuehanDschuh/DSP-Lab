function [s1,s2,s3] = untitled2(x1,x2,x3,sigmaZ1,sigmaZ2,sigmaZ3)


end

