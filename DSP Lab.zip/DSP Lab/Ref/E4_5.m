load('noise_5insx.mat')
load('speech.mat')
fs=8192;
soundsc(x_speech,fs)
soundsc(x_5insx,fs)


X=x_speech;
SNR1=0;
SNR2=3;
[Y,NOISE] = add_noise_model(X,SNR1,SNR2);

M=length(Y);
f=fs*(0:1/M:1-1/M);
Ys=fft(Y,M);
plot(f,abs(Ys))
title('speech signal and niose signal in frequency domain')
xlabel('f')
ylabel('Ys')

n=34;
b = fir1(n,0.5);
freqz(b,1,512)
outlo = filter(b,1,y);
L=length(outlo);
f=fs*(0:1/L:1-1/L);
O=fft(outlo,L);
plot(f,abs(O))
soundsc(outlo,fs)