N=32;
n=0:N-1;
x=0.8*sin(0.2*pi*n);
M=N;
w=2*pi*(0:1/M:1-1/M);
X=fft(x,M);
L=length(X);
wk=2*pi*(0:1/L:1-1/L);
stem(wk,abs(X))
title('X=fft(L,x)')
xlabel('w')
ylabel('X')
Xd=dft(N,x);
stem(w,abs(Xd))
title('Xd=dft(N,x)')
xlabel('w')
ylabel('Xd')


r_fft=[];
r_dft=[];
for k=4:8
N=2.^k;
tic
X=fft(x,N);
r_fft=[r_fft;toc];
tic
Xd=dft(N,x);
r_dft=[r_dft,toc];
end

N=[16 32 64 128 256];
plot(N,r_fft)
title('the number of computations of fft function')
xlabel('N')
ylabel('r-fft')
plot(N,r_dft)
title('the number of computations of dft program')
xlabel('N')
ylabel('r-dft')




