fp=150;
fsb=100;
fs=1000;
Wp1=2*fp/fs;
Ws1=2*fsb/fs;
Rp1=1;
Rs1=40;
[n1,Ws1] = cheb2ord(Wp1,Ws1,Rp1,Rs1);
[b,a] = cheby2(n1,Rs1,Ws1);
freqz(b,a)
% use chebyshev Type II to design the IIR highpass filter
%Nsampling = 1/300; 
%t = -0.5 : Nsampling : 0.5;
t=[0:300-1]/fs;
xs=5*sin(200*pi*t)+2*cos(300*pi*t);
stem(t,xs)

xlabel('t')
ylabel('magnitude')
title('original sequence')
Xs=fft(xs);
plot(abs(Xs))
%original sequence
xo= filter(b,a,xs);
stem(t,xo)
xlabel('t')
ylabel('magnitude')
title('output sequence')
Xo=fft(xo);
plot(abs(Xo))

filtered_data=filter(b,a,xs);
% Calculate FFT
fftpts=300; % number points in FFT
hpts=fftpts/2; % half number of FFT points
binwidth=fs/fftpts;
f=[0:binwidth:fs-binwidth];
x_fft=abs(fft(xs))/hpts; %scaled FFT of original signal
filtered_fft=abs(fft(filtered_data))/hpts;

subplot(2,2,1)
plot(t,xs);
title('Raw Time Series');
subplot(2,2,3)
plot(t,filtered_data);
title('Filtered Time Series');
xlabel('Time (s)');
subplot(2,2,2)
plot(f(1:hpts),x_fft(1:hpts));
title('Raw FFT');
subplot(2,2,4)
plot(f(1:hpts),filtered_fft(1:hpts));
title('Filtered FFT');
xlabel('Frequency (Hz)');

%output sequence


Wc2=0.44;
dW2=0.08;
Ws3=Wc2-dW2/2;
Ws2=Wc2+dW2/2;
Rp2=1;
Rs2=100;
%[n2,Wn] = ellipord(Wp2,Ws2,Rp2,Rs2);
n2=10;
[b2,a2] = ellip(n2,Rp2,Rs2,[Ws3,Ws2],'stop');
freqz(b2,a2)
title('frequency response of elliptic bandstop filter')
%xlabel('normalized frequency')
%ylabel('magnitude/dB')


n=0:200;
xe=sin(0.44*pi*n);
Xe=fft(xe);
plot(abs(Xe))
stem(n,xe)
xlabel('t')
ylabel('magnitude')
title('original sequence')
xo2= filter(b2,a2,xe);
stem(n,xo2)
xlabel('t')
ylabel('magnitude')
title('output sequence')
Xo2=fft(xo2);
plot(abs(Xo2))