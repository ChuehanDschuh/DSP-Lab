xn=read_radar_data('G09_NormalWalking1.dat');
xa=read_radar_data('G09_AbnormakWalking1.dat');
figure
plot(abs(xn))
title('data of normal walking')
figure
plot(abs(xa))
title('data of abnormal walking')



%%
xn=read_radar_data('G09_NormalWalking2.dat');
xa=read_radar_data('G09_AbnormalWalking2.dat');
Ts=10;
fs=1/Ts;
L=256;
Sxn=stft(xn,fs,'Window',hamming(L),'FFTLength',2048);
lxn=get_noise_thr(Sxn);
figure
imagesc(abs(Sxn))
colorbar
figure
plot(abs(Sxn))
title('STFT of normal walking')
Sxa=stft(xa,fs,'Window',hamming(L),'FFTLength',2048);
figure
plot(abs(Sxa))
title('STFT of abnormal walking')

%Sn=spectrogram(xn,blackman(128),60,128,1e3);
%plot(abs(Sn))
%set(gca,'YDir','reverse');

Sn=10*log10((abs(Sxn)).^2);
plot(Sn)
ln=get_noise_thr(Sn);
figure
x=[10:0];
y=[0:500];
imagesc(x,y,Sn)
%set(gca,'ydir','normal');
colorbar
caxis([ln,60])
title('spectrogram of normal walking')





Sa=10*log10((abs(Sxa)).^2);
la=get_noise_thr(Sa);
figure
x=[10:0];
y=[0:500];
imagesc(x,y,Sa);
%set(gca,'ydir','normal')
colorbar
caxis([la 60])
title('spectrogram of abnormal walking')


Sn1=Sn(:,1:250);
figure
x=[0:5];
y=[-250:250];
imagesc(x,y,Sn1)
set(gca,'ydir','normal')
ylabel('frequecy')
xlabel('time')
title('toward from radar movement')
colorbar
caxis([20 60])


Sn2=Sn(:,299:500);
figure
x=[0:5];
y=[-250:250];
imagesc(x,y,Sn2)
set(gca,'ydir','normal')
ylabel('frequecy')
xlabel('time')
title('away from radar movement')
colorbar
caxis([20 60])

Sa1=Sa(:,1:200);
figure
x=[0:5];
y=[-250:250];
imagesc(x,y,Sa1)
set(gca,'ydir','normal')
ylabel('frequecy')
xlabel('time')
title('toward from radar movement')
colorbar
caxis([20 60])


Sa2=Sa(:,400:597);
figure
x=[0:5];
y=[-250:250];
imagesc(x,y,Sa2)
set(gca,'ydir','normal')
ylabel('frequecy')
xlabel('time')
title('away from radar movement')
colorbar
caxis([20 60])

%%



