function [] = ROC(thetai, sigmaZ1, sigmaZ2, sigmaZ3)

SNR1=10;
sigmaZ1=sqrt(10^(-SNR1/10));
SNR2=0;
sigmaZ2=sqrt(10^(-SNR2/10));
SNR3=-10;
sigmaZ3=sqrt(10^(-SNR3/10));

N=100;
i=1:100;
w=4*pi/N;
Alpha=0;
si0=sin(w*i + Alpha);
si=si0';
muZ=0;
n=50;
thetai=[0,1];
random_num = thetai(randi(numel(thetai),1,n));
random_num = sort(random_num);
T=[random_num,random_num];
N1 = normrnd(muZ,sigmaZ1,N,1);
N2 = normrnd(muZ,sigmaZ2,N,1);
N3 = normrnd(muZ,sigmaZ3,N,1);
xd1=T'.*si+N1;
xd2=T'.*si+N2;
xd3=T'.*si+N3;


muh=0;
muk=1;
lamba1=xd1;
lamba2=xd2;
lamba3=xd3;
pfa1 = normcdf(-lamba1,muh,sigmaZ1);
pfa2 = normcdf(-lamba2,muh,sigmaZ2);
pfa3 = normcdf(-lamba3,muh,sigmaZ3);
pd1 =1-normcdf(lamba1,muk,sigmaZ1);
pd2 =1-normcdf(lamba2,muk,sigmaZ2);
pd3 =1-normcdf(lamba3,muk,sigmaZ3);

roc1=stem(pfa1,pd1,'LineStyle','none');
hold on
roc2=stem(pfa2,pd2,'LineStyle','none');
hold on
roc3=stem(pfa3,pd3,'LineStyle','none');
legend('SNR1=10', 'SNR2=0' ,'SNR3=-10')
xlabel('P_{FA}')
ylabel('P_{D}')
disp(pfa1)
end

