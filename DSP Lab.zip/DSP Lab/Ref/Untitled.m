fp1=150;
fs1=100;
Fs=1000;
Fs2=Fs/2;
Wp=fp1/Fs2; Ws=fs1/Fs2;
Rp=1; Rs=30;
[n,Wn]=buttord(Wp,Ws,Rp,Rs);
[b2,a2]=butter(n,Wn,'high','s');
t=[0:300-1]/fs;
xs=5*sin(200*pi*t)+2*cos(300*pi*t);
plot(xs)
y=filter(b2,a2,xs);
plot(y)