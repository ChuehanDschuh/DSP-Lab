function [B] = DesignLowerFilter(Wo)
fs = 8000;    N = 400;    k = 2*pi/fs; Bandwidth = 70;
wc1 = ( Wo - Bandwidth / 2 ) * k;
wc2 = ( Wo + Bandwidth / 2 ) * k;
B = fir2(N,[0,wc1/pi,wc2/pi,1],[0,1,1,0]);
end

