function [tel] = dtmfcoef(Y,N)

a=abs(Y);
p=a.*a/10000;
for i=1
num(1)=find(p(1:35)==max(p(1:35))); % 找行频
num(2)=35+find(p(35:60)==max(p(35:60))); % 找列频
if (num(1) < 24) row=1; % 确定行数
elseif (num(1) < 27) row=2;
elseif (num(1) < 30) row=3;
else row=4;
end

if (num(2) < 42) column=1; % 确定列数
elseif (num(2) < 46) column=2;
elseif (num(2) < 52) column=3;   
else column=4;
end
z=[row,column]; % 确定数字
if z==[1,1] tel=1;
elseif z==[1,2] tel=2;
elseif z==[1,3] tel=3;
elseif z==[1,4] tel=A;
elseif z==[2,1] tel=4;
elseif z==[2,2] tel=5;
elseif z==[2,3] tel=6;   
elseif z==[2,4] tel=B;
elseif z==[3,1] tel=7;
elseif z==[3,2] tel=8;
elseif z==[3,3] tel=9;
elseif z==[3,4] tel=C;
elseif z==[4,1] tel='*';
elseif z==[4,2] tel=0;    
elseif z==[4,3] tel='#';
elseif z==[4,4] tel=D;
    
end
disp(tel)
end


