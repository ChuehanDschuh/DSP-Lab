function [Cxx] = spec2(X,N)
Xw=fft(X);
Ixx=((abs(Xw)).^2)/N;
Cxx=smoothdata(Ixx,'movmedian',71);
end

