N=100;
%i=1:100;
%w=4*pi/N;
%Alpha=0;
%si0=sin(w*i + Alpha)+1;
%si=si0';
si=ones(100,1);
muZ=0;
theta=1;
SNR1=10;
sigmaZ1=sqrt(10^(-SNR1/10));
SNR2=0;
sigmaZ2=sqrt(10^(-SNR2/10));
SNR3=-10;
sigmaZ3=sqrt(10^(-SNR3/10));
[x1,x2,x3] = genSignals(N, si, theta, muZ, sigmaZ1, sigmaZ2, sigmaZ3);
plot(x1)
hold on
plot(x2)
hold on 
plot(x3)
legend('x1(SNR1=10)','x2(SNR2=0)','x3(SNR3=-10)')

subplot(3,1,1)
plot(x1)
xlabel('ni=N1,i=1,...,N')
ylabel('x1')
title('SNR1=10')
subplot(3,1,2)
plot(x2)
xlabel('ni=N2,i=1,...,N')
ylabel('x2')
title('SNR2=0')
subplot(3,1,3)
plot(x1)
xlabel('ni=N3,i=1,...,N')
ylabel('x3')
title('SNR3=-10')

theta_hat_1=(1/N)*sum(x1);
disp(theta_hat_1)
theta_hat_2=(1/N)*sum(x2);
disp(theta_hat_2)
theta_hat_3=(1/N)*sum(x3);
disp(theta_hat_3)


muk1=theta_hat_1;
muk2=theta_hat_2;
muk3=theta_hat_3;
[s1, s2, s3] = detector(x1, x2, x3, sigmaZ1, sigmaZ2, sigmaZ3,muk1,muk2,muk3);

%n=50;
thetai=[0,1];
%random_num = thetai(randi(numel(thetai),1,n));
%random_num = sort(random_num);
%T=[random_num,random_num];
%This part is second way to get a theta(i),but the first way is more clear
y = randsample(thetai,50,true);
T=[y,y];
stem(T)

N1 = normrnd(muZ,sigmaZ1,N,1);
N2 = normrnd(muZ,sigmaZ2,N,1);
N3 = normrnd(muZ,sigmaZ3,N,1);
xd1=T'.*si+N1;
xd2=T'.*si+N2;
xd3=T'.*si+N3;
[sd1, sd2, sd3] = detector(xd1, xd2, xd3, sigmaZ1, sigmaZ2, sigmaZ3,muk1,muk2,muk3);

subplot(3,2,1)
stem(xd1)
xlabel('ni=N1,i=1,...,N')
ylabel('xd1')
title('SNR1=10')
subplot(3,2,2)
stem(sd1)
xlabel('ni=N1,i=1,...,N')
ylabel('sd1(present is 1 and absent is 0)')
title('SNR1=10')
subplot(3,2,3)
stem(xd2)
xlabel('ni=N2,i=1,...,N')
ylabel('xd2')
title('SNR2=0')
subplot(3,2,4)
stem(sd2)
xlabel('ni=N2,i=1,...,N')
ylabel('sd2)')
title('SNR2=0')
subplot(3,2,5)
stem(xd3)
xlabel('ni=N3,i=1,...,N')
ylabel('xd3')
title('SNR3=-10')
subplot(3,2,6)
stem(sd3)
xlabel('ni=N3,i=1,...,N')
ylabel('sd3')
title('SNR3=-10')

