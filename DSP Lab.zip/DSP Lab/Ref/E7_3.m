N1=64;
n1=1:N1;
X1(n1)=sin(0.2*pi*n1)+2*sin(0.4*pi*n1)+sin(0.45*pi*n1);
var=0.5;
z1=(sqrt(var)*randn(N1,1)).';
Xo=X1(n1)+z1;
X64 = [Xo zeros(1,192)];
plot(X64)


Xw1=fft(X64);
Ixx1=((abs(Xw1)).^2)/N1;
plot(Ixx1)
plot(10*log10(abs(Ixx1)))
title('The periodgram with N=64')
ylabel('magnitude/dB')

N2=256;
n2=1:N2;
X2(n2)=sin(0.2*pi*n2)+2*sin(0.4*pi*n2)+sin(0.45*pi*n2);
z(n2)=(sqrt(var)*randn(N2,1)).';
X256=X2(n2)+z(n2);
plot(X256)

Xw2=fft(X256);
Ixx2=((abs(Xw2)).^2)/N2;
plot(Ixx2)
plot(10*log10(abs(Ixx2)))
title('The periodgram with N=256')
ylabel('magnitude/dB')


%2.averaged periodogram

x=X256;
L=4;
%[Cxx,CxxL] = spec(x,L);
X = x';
M= round(size(X,1) / L);
Mhalf = round(M/2);
s= [];
for i = (0:L-1)
    for j = (1:M)
        s(i+1,j) = X(i*M+j,1);
    end
end

rw = rectwin(M);
ss = [];
SS = ones(L,M);
Ps = ones(L,M);

for i = (0:L-1)
    for j = (1:M)
        ss(i+1,j) = rw(j) * s(i+1,j);
        SS(i+1,:) = fft(ss(i+1,:),M);
        Ps(i+1,:) = (abs(SS(i+1,:))).^2 ./ sum(abs(rw).^2) ;
        
    end
end

suma = sum(Ps);
Cxx = suma ./ L;
%CxxL= 10*log10(Cxx);
figure();
plot(10*log10(Cxx))
title('The averaged periodogram with N=256 and L=4')
ylabel('magnitude/dB')
%3.
x=1:N2;
XR=(N2/4)*dirac(x)+(sqrt(var)*randn(N2,1)).';
XRw=fft(XR);
plot(abs(XRw));
title('The true spectrum ')
ylabel('magnitude/dB')

