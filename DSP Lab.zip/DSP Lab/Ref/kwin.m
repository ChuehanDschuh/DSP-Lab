function [N,beta,kai] = kwin(deltaw, A)
%deltaw = 0.06*pi;
%A = 30;

N = ceil(((A-8)/(2.285*deltaw))+1);

if A < 21
    beta = 0;
elseif  A>= 21 & A < 50
    beta = (0.5842*(A-21)^0.4) + 0.07866*(A-21);
elseif  A>=50
    beta = 0.1102*(A-8.7);
end


for n=1:N
kai(n) = besseli(0, beta *sqrt(1- ( (2*n/N-1)-1)^2 )/besseli(0,beta)) ;
end

end