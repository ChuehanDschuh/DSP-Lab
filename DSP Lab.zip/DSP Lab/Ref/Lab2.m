n=-10:20;
x1=sin(0.12*pi*n);
subplot(2,3,1)
stem(n,x1)

x2=+(n>0)-+(n>6);
subplot(2,3,2)
stem(n,x2)

a1=0.9;
u=+(n>0);
e=a1.^n;
x3=e.*u;
subplot(2,3,3)
stem(n,x3)

d1=+(n==1);
d2=+(n==2);
d3=+(n==3);
x4=0.5*d1+d2+0.5*d3;
subplot(2,3,4)
stem(n,x4)

x5=e.*cos(0.2*pi*n);
subplot(2,3,5)
stem(n,x5)

x6=sinc(0.2*n);
subplot(2,3,6)
stem(n,x6)

d1=+(n==1);
d2=+(n==2);
d3=+(n==3);
d4=+(n==4);
h=0.2*d1+0.2*d2+0.2*d3+0.2*d4;

n=1:9;
x1=1;
conv

load pianoG3.mat;
sound(y);







