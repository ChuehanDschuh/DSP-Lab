%load the signal into variable x
load ma3.mat


%create the cross correlation coefficients of the signal 
%MA(3) q=3 so lags go from -3 to 3
%c is literally the polynomial of the cross correlation function
[c,lags] = xcorr(x,3);
stem(lags,c)
%we obtain the roots of that polynomial and proof wheter they are
%within the unit circle
pr = roots(c);
len = size(pr,1)
B = [];

%find the roots within the unit circle
for i = 1:1:len
    if abs(pr(i)) <= 1
        B = [B,pr(i)]
    end
end


num = [1, B]
den = 1;

numt = [1 0.4 -0.2 0.15];
dent = 1;


[h,w] = freqz(num, den,100);
figure();
plot(w,-abs(h))
title('Estimated expectrum')
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (Linear)')



[h1,w1] = freqz(numt, den,100);
figure();
plot(w1,(abs(h1)))
title('Real spectrum')
xlabel('Normalized Frequency (\times\pi rad/sample)')
ylabel('Magnitude (Linear)')



