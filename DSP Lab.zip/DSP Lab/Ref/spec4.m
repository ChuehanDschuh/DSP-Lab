%function [x,y] = spec()

L= 5;
M= size(X,1) / L;
s= [];

for i = (0:L-1)
    for j = (1:M)
        s(i+1,j) = X(i*M+j,1);
    end
end

rw = hamming(M);
ss = [];
SS = ones(L,M);
Ps = ones(L,M);

for i = (0:L-1)
    for j = (1:M)
        ss(i+1,j) = rw(j) * s(i+1,j);
        SS(i+1,:) = fft(ss(i+1,:),M);
        Ps(i+1,:) = (abs(SS(i+1,:))).^2 ./ sum(abs(rw).^2) ;
        
    end
end

% ss1 = rw' .* s;
% 
% SS1 = fft(ss1(1,:), M);
% 
% SSAb1 = (abs(SS1).^2) ./ sum(rw.^2) ;

suma = sum(Ps);

Cxx = suma ./ L;
plot(Cxx)
title('Estimated spectrum of the data (L=10)')


CxxL= 10*log10(Cxx);
figure();
plot(CxxL)
title('The log-spectrum(L=5)')

alpha=1-0.95;
N_alpha=norminv(alpha/2);
disp(N_alpha)

conf1=CxxL + (10*log10(exp(1)*N_alpha/sqrt(L)));
conf2 = CxxL - (10*log10(exp(1)*N_alpha/sqrt(L)));

