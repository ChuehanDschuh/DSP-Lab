function [AIC,MDL] =order ()

load('arunknown.mat')
N=1000;
a1= aryule(X,1);
a2= aryule(X,2);
a3= aryule(X,3);
a4= aryule(X,4);
a5= aryule(X,5);
a6= aryule(X,6);
a7= aryule(X,7);
a8= aryule(X,8);
a9= aryule(X,9);
a10= aryule(X,10);
a=[a1 a2 a3 a4 a5 a6 a7 a8 a9 a10];

for m=1:10
  for k=1:m
   for n=m+1:N
    for nu=2:k
    f=sum(nu);
   s1(k,n,f)=sum(a(1,f:f+k)*X(n-k));
  s2(n)=sum((X(n)+s1(k,n,f)).^2);
  sigmazm2(m)=1/(N-m)*s2(n);
  AIC(m)=log(sigmazm2(m))+m*2/N;
  MDL(m)=log(sigmazm2(m))+m*log(N)/N;
   end
  end
  end
end
disp(AIC)
disp(MDL)
m=1:10;
plot(m,AIC)
plot(m,MDL)

end

